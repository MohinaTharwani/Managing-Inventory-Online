<?php
/**
 * Created by PhpStorm.
 * User: Jeswani Tarun Haresh
 * Date: 10/24/2016
 * Time: 6:01 PM
 */


require_once("config.php");

$thisuserid = $_GET['UserID'];
echo $thisuserid;

$founduser = deleteuser($thisuserid);
echo "<pre>";
print_r($founduser);
echo "</pre>";
?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
    <title>
        Delete
    </title>
    <!-- Style -- Can also be included as a file usually style.css -->
    <style type="text/css">
        table.table-style-three {
            font-family: verdana, arial, sans-serif;
            font-size: 11px;
            color: #333333;
            border-width: 1px;
            border-color: #3A3A3A;
            border-collapse: collapse;
        }
        table.table-style-three th {
            border-width: 1px;
            padding: 8px;
            border-style: solid;
            border-color: #FFA6A6;
            background-color: #D56A6A;
            color: #ffffff;
        }
        table.table-style-three a {
            color: #ffffff;
            text-decoration: none;
        }

        table.table-style-three tr:hover td {
            cursor: pointer;
        }
        table.table-style-three tr:nth-child(even) td{
            background-color: #F7CFCF;
        }
        table.table-style-three td {
            border-width: 1px;
            padding: 8px;
            border-style: solid;
            border-color: #FFA6A6;
            background-color: #ffffff;
        }
    </style>

</head>
<body>

<form name="" method="post" action="processdeleteuser.php">
    <table class="table-style-three">
        <?php foreach ($founduser as $userdetails) { ?>
            <tr><td>FirstName :</td>      <td><input type="text" name="FirstName" value="<?php print $userdetails['FirstName']; ?>"></td></tr>
            <tr><td>LastName :</td>       <td><input type="text" name="LastName" value="<?php print $userdetails['LastName']; ?>"></td></tr>
            <tr><td>Email :</td>  <td><input type="text" name="Email" value="<?php print $userdetails['Email']; ?>"></td></tr>
            <tr><td>MemberSince :</td>          <td><input type="text" name="MemberSince" value="<?php print $userdetails['MemberSince']; ?>"></td></tr>
            <tr><td>Active :</td>           <td><input type="text" name="Active" value="<?php print $userdetails['Active']; ?>"></td></tr>
            <tr><td>role:</td>            <td><input type="text" name="role" value="<?php print $userdetails['role']; ?>"></td></tr>
            <tr><td>request : </td>      <td><input type="text" name="request" value="<?php print $userdetails['request'];?>"></td></tr>

            <input type="hidden" name="UserID" value="<?php print $userdetails['UserID'];?>" >
        <?php } ?>
    </table>

    <input type="submit" name="submit" value="Delete Record">

</form>


</body>
</html>