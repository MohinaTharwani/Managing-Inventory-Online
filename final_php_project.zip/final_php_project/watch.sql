--
-- Database: `watch`
--

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `watch_id` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `description` varchar(150) NOT NULL,
  `price` double NOT NULL,
  `quantity` int(11) NOT NULL,
  `availability` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`watch_id`, `name`, `type`, `brand`, `description`, `price`, `quantity`, `availability`, `gender`, `image`) VALUES
('k1fmxu', 'Sport Watch 1', 'sports_watch', 'Invicta', 'INvicta', 250, 23, 'In Stock', '', '123.jpg'),
('li9sf6', 'Invicta Watch1', 'casual_wear', 'Invicta', 'Invicta!!!!!!', 220, 20, 'In Stock', 'male', 'longinesm2.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `userdetails`
--

CREATE TABLE `userdetails` (
  `UserID` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Email` varchar(150) NOT NULL,
  `Password` varchar(1000) NOT NULL,
  `MemberSince` varchar(255) NOT NULL,
  `Active` int(11) NOT NULL,
  `role` int(11) NOT NULL DEFAULT '1',
  `request` bit(1) NOT NULL DEFAULT b'0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetails`
--

INSERT INTO `userdetails` (`UserID`, `FirstName`, `LastName`, `Email`, `Password`, `MemberSince`, `Active`, `role`, `request`) VALUES
('86qu88', 'Tarun', 'Jeswani', 'jeswanitarun@gmail.com', 'de3dfb6cad004a5d9c03b2e2bb4f99d4ca2700a5826bddd917d20033bd0092943', '1482286635', 1, 10, b'0'),
('3jf1ui', 'Mohina', 'Tharwani', 'mohina@gmail.com', '3c9e83b6e8ddeb97eaa689cbc21a4e86a3a4d6d8f4f737c514a56559a008acbbc', '1482355325', 1, 1, b'0'),
('p6puyp', 'Pravin', 'M', 'pravinm@gmail.com', '97a9aa0d458362afb74d78066de49716e9b20691c0a491a9c13d53efe417021f0', '1482364709', 1, 1, b'0'),
('e54rxx', 'Gaurav', 'Samant', 'samantgau@gmail.com', '74eea660f144c58800a2b429da6bffe36bc2983549c3dc844781db283318848c0', '1482355304', 1, 1, b'0'),
('wmifhk', 'Shreyas', 'Najan', 'shreyas@gmail.com', 'd5c8469620bd847101051293d8ec11df064b88367eca8668f3c4e2ce0a2ab2464', '1482355343', 1, 1, b'0');

-- --------------------------------------------------------

--
-- Table structure for table `whomadewho`
--

CREATE TABLE `whomadewho` (
  `uniqueid` int(11) NOT NULL,
  `watchid` varchar(50) NOT NULL,
  `userid` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`watch_id`);

--
-- Indexes for table `userdetails`
--
ALTER TABLE `userdetails`
  ADD PRIMARY KEY (`Email`),
  ADD KEY `userdetails_userroles_role_fk` (`role`);

--
-- Indexes for table `whomadewho`
--
ALTER TABLE `whomadewho`
  ADD PRIMARY KEY (`uniqueid`);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `userdetails`
--
ALTER TABLE `userdetails`
  ADD CONSTRAINT `userdetails_userroles_role_fk` FOREIGN KEY (`role`) REFERENCES `userroles` (`role`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
