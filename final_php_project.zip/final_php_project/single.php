<?php
require_once("config.php");
session_start();






// print_r is to display the contents of an array() in PHP.
//print_r($_POST);

// Assigning $_POST values to individual variables for reuse.
$name = $_POST['name'];
$type = $_POST['type'];
$brand = $_POST['brand'];
$description = $_POST['description'];
$price = $_POST['price'];
$quantity = $_POST['quantity'];
$availability = $_POST['availability'];
$gender = $_POST['gender'];
//$image = $_POST['image'];
$thiswatchid = $_POST['watch_id'];

$image = $_SESSION['image'];


//Creating a variable to hold the "@return boolean value returned by function updateThisRecord - is boolean 1 with
//successfull and 0 when there is an error with executing the query .
$updatedRecord  = fetchThisProduct($name, $type, $brand, $description, $price, $quantity, $availability, $gender,$image,$thiswatchid);



//display the result that was returned by the createNewUser function - in this case we usually get a 1 when the
//update is completed successfully.
echo $name;

echo $price;

?>


