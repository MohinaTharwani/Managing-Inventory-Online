<?php
/**
 * Created by PhpStorm.
 * User: Jeswani Tarun Haresh
 * Date: 12/17/2016
 * Time: 8:05 PM
 */
function insertmen($name, $type, $brand, $description, $price, $quantity, $availability, $gender, $image)
{
    global $mysqli;
    //Generate A random userid
    $character_array = array_merge(range('a', 'z'), range(0, 9));
    $rand_string = "";
    for ($i = 0; $i < 6; $i++) {
        $rand_string .= $character_array[rand(
            0, (count($character_array) - 1)
        )];
    }

            $stmt = $mysqli->prepare(
                "INSERT INTO product (
    		watch_id, name,type,brand,description,price,quantity,availability,gender, image
    		)
    		VALUES (
    		'" . $rand_string . "',
    		?,
    		?,
    		?,
    		?,
    		?,
    		?,
            ?,
            ?,
            ?
            )"
            );
            $stmt->bind_param("ssssiisss", $name, $type, $brand, $description, $price, $quantity, $availability, $gender, $image);
            $result = $stmt->execute();
            $stmt->close();
           // echo "<br>User record has been successfully created<br/>";
            return $result;

}
function fetchAll() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		watch_id,name,type, brand, description,price, quantity, availability, gender,image

		FROM product  ");
    $stmt->execute();
    $stmt->bind_result($watch_id,
        $name,$type, $brand,$description,$price,$quantity,$availability,$gender, $image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'watch_id' => $watch_id,
            'name'                      => $name,
            'type' => $type,
            'brand'                  => $brand,
            'description' => $description,

            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image

        );
    }
    $stmt->close();
    return ($row);
};

function fetchAllmen() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,image

		FROM product where gender='male'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'image' => $image

        );
    }
    $stmt->close();
    return ($row);
};


function fetchAllwomen() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,image

		FROM product where gender='female'   ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchCasualmen() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,image

		FROM product where gender='male' and type='casual_wear'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};


function fetchSportmen() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,image

		FROM product where gender='male' and type='sports_watch'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchSmartmen() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,image

		FROM product where gender='male' and type='smart_watch'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchCasualwomen() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,image

		FROM product where gender='female' and type='casual_wear'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchSportwomen() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,image

		FROM product where gender='female' and type='sports_watch'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchSmartwomen() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,image

		FROM product where gender='female' and type='casual_wear'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};
function fetchMenRolex() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where gender='male' and brand='rolex'   ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
                        'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchWomenRolex() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where gender='female' and brand='rolex'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};


function fetchRolex() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='rolex'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' =>$image

        );
    }
    $stmt->close();
    return ($row);
};

function fetchFossil() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='fossil'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender, $image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image'                 =>$image

        );
    }
    $stmt->close();
    return ($row);
};

function fetchWomenFossil() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='fossil' and gender='female'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchMenFossil() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='fossil' and gender='male'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchInvicta() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='invicta'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchWomenInvicta() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='invicta' and gender='female'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchMenInvicta() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='invicta' and gender='male'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchGuess() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='guess'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchWomenGuess() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='guess' and gender='female'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function fetchMenGuess() {
    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "SELECT
		name,brand,price,quantity,availability,gender,image

		FROM product where brand='guess' and gender='male'  ");
    $stmt->execute();
    $stmt->bind_result(
        $name,$brand,$price,$quantity,$availability,$gender,$image
    );
    while ($stmt->fetch()) {
        $row [] = array(
            'name'                      => $name,
            'brand'                  => $brand,
            'price'               => $price,
            'quantity'                => $quantity,
            'availability'                    => $availability,
            'gender'                 =>$gender,
            'image' => $image


        );
    }
    $stmt->close();
    return ($row);
};

function deletewatch($watch_id){
    global $mysqli;
    $stmt = $mysqli->prepare("DELETE FROM product WHERE watch_id = ? ");
    $stmt->bind_param('s',$watch_id);
    $result = $stmt->execute();
    $stmt->close();
    return "<br>Delete record</br>";
}

function isUserLoggedIn()
{
    global $loggedInUser,$mysqli,$db_table_prefix;
    $stmt = $mysqli->prepare("SELECT
		UserID,
		Password
		FROM ".$db_table_prefix."UserDetails
		WHERE
		UserID = ?
		AND
		Password = ?
		AND
		active = 1
		LIMIT 1");
    $stmt->bind_param("is", $loggedInUser->user_id, $loggedInUser->hash_pw);
    $stmt->execute();
    $stmt->store_result();
    $num_returns = $stmt->num_rows;
    $stmt->close();

    if($loggedInUser == NULL)
    {
        return false;
    }
    else
    {
        if ($num_returns > 0)
        {
            return true;
        }
        else
        {
            destroySession("ThisUser");
            return false;
        }
    }
}

function destroySession($name) {
    if(isset($_SESSION[$name]))
    {
        $_SESSION[$name] = NULL;
        unset($_SESSION[$name]);
    }
}

function getUniqueCode($length = "") {
    $code = md5(uniqid(rand(), TRUE));
    if ($length != "") {
        return substr($code, 0, $length);
    } else {
        return $code;
    }
}

function generateHash($plainText, $salt = NULL) {
    if ($salt === NULL) {
        $salt = substr(md5(uniqid(rand(), TRUE)), 0, 25);
    } else {
        $salt = substr($salt, 0, 25);
    }
    return $salt . sha1($salt . $plainText);
}

function createNewUser($firstname, $lastname, $email, $password)
{
    global $mysqli, $db_table_prefix;
    //Generate A random userid

    $character_array = array_merge(range('a', 'z'), range(0, 9));
    $rand_string = "";
    for ($i = 0; $i < 6; $i++) {
        $rand_string .= $character_array[rand(
            0, (count($character_array) - 1)
        )];
    }

    //$rand_string = getUniqueCode(14);
    //echo $rand_string;
    //echo $username;
    //echo $firstname;
    //echo $lastname;
    //echo $email;
    //echo $password;

    $newpassword = generateHash($password);

    echo $newpassword;


    $stmt = $mysqli->prepare(
        "INSERT INTO " . $db_table_prefix . "UserDetails (
		UserID,
		FirstName,
		LastName,
		Email,
		Password,
		MemberSince,
		Active
		)
		VALUES (
		'" . $rand_string . "',
		?,
		?,
		?,
		?,
        '" . time() . "',
        1
		)"
    );
    $stmt->bind_param("ssss", $firstname, $lastname, $email, $newpassword);
    //print_r($stmt);
    $result = $stmt->execute();
    //print_r($result);
    $stmt->close();
    return $result;

}


function request($userid){
    global $mysqli,$db_table_prefix;
    $stmt = $mysqli->prepare("UPDATE `UserDetails` SET `request`= 'requested' WHERE `UserID` = ?");
    $stmt->bind_param("s",$userid);
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}


function updateThisUser($userid,$userName,$FirstName,$LastName,$Email,$role){

    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "UPDATE UserDetails
    SET
    UserName = ?,
    FirstName = ?,
    LastName = ?,
    Email = ?,
    role = ?
    WHERE
    UserID = ?
    LIMIT 1"
    );
    $stmt->bind_param("ssssss", $userName, $FirstName, $LastName, $Email, $role,$userid);
    $result = $stmt->execute();
    $stmt->close();

    return $result;
}

function getRequest() {

    global $mysqli,$db_table_prefix;
    $stmt = $mysqli->prepare("SELECT
    UserID,
    UserName,
    FirstName,
    LastName,
    Email,
    Password,
    MemberSince,
    Active,
    request
    FROM `UserDetails` WHERE `request` = 'requested' AND `role` = 'generalUser'");

    $stmt->execute();
    $stmt->bind_result($UserID, $UserName, $FirstName, $LastName, $Email, $Password, $MemberSince, $Active,$request);
    while ($stmt->fetch()){
        $row[] = array('UserID' => $UserID,
            'UserName' => $UserName,
            'FirstName' => $FirstName,
            'LastName' => $LastName,
            'Email' => $Email,
            'Password' => $Password,
            'MemberSince' => $MemberSince,
            'Active' => $Active,
            'request'=>$request);
    }
    $stmt->close();
    return ($row);
}
function fetchAllBlogsAdmin() {
    global $mysqli,$db_table_prefix;
    $stmt = $mysqli->prepare("SELECT
    bloglisting.blogid,
    bloglisting.title,
      bloglisting.datecreated,
      bloglisting.deleteflag,
      bloglisting.active,
      whomadewho.userid,
      blogcontent.blogcontent,
      UserDetails.UserName,
      UserDetails.FirstName,
      UserDetails.LastName,
      UserDetails.Email

        FROM whomadewho INNER JOIN bloglisting ON whomadewho.blogid = bloglisting.blogid
   INNER JOIN UserDetails ON whomadewho.userid = UserDetails.UserID
   INNER JOIN blogcontent ON blogcontent.blogid = bloglisting.blogid
    ");

    $stmt->execute();
    $stmt->bind_result($blogid, $title, $datecreated, $deleteflag, $active, $userid, $blogcontent, $username, $firstname, $lastname, $email);
    while ($stmt->fetch()){
        $row[] = array('blogid' => $blogid,
            'title' => $title,
            'datecreated' => $datecreated,
            'deleteflag' => $deleteflag,
            'active' => $active,
            'userid' => $userid,
            'blogcontent' => $blogcontent,
            'username' => $username,
            'firstname' => $firstname,
            'lastname' => $lastname,
            'email'  => $email
        );
    }
    $stmt->close();
    return ($row);
}


function fetchAllBlogsSuper() {
    global $mysqli,$db_table_prefix;
    $stmt = $mysqli->prepare("SELECT
    bloglisting.blogid,
    bloglisting.title,
      bloglisting.datecreated,
      bloglisting.deleteflag,
      bloglisting.active,
      whomadewho.userid,
      blogcontent.blogcontent,
      UserDetails.UserName,
      UserDetails.FirstName,
      UserDetails.LastName,
      UserDetails.Email

        FROM whomadewho INNER JOIN bloglisting ON whomadewho.blogid = bloglisting.blogid
   INNER JOIN UserDetails ON whomadewho.userid = UserDetails.UserID
   INNER JOIN blogcontent ON blogcontent.blogid = bloglisting.blogid WHERE bloglisting.active = 0
    ");

    $stmt->execute();
    $stmt->bind_result($blogid, $title, $datecreated, $deleteflag, $active, $userid, $blogcontent, $username, $firstname, $lastname, $email);
    while ($stmt->fetch()){
        $row[] = array('blogid' => $blogid,
            'title' => $title,
            'datecreated' => $datecreated,
            'deleteflag' => $deleteflag,
            'active' => $active,
            'userid' => $userid,
            'blogcontent' => $blogcontent,
            'username' => $username,
            'firstname' => $firstname,
            'lastname' => $lastname,
            'email'  => $email
        );
    }
    $stmt->close();
    return ($row);
}

function fetchMyBlogs() {
    global $loggedInUser, $mysqli,$db_table_prefix;
    $stmt = $mysqli->prepare("SELECT
		bloglisting.blogid,
		bloglisting.title,
	    bloglisting.datecreated,
	    bloglisting.deleteflag,
	    bloglisting.active,
	    whomadewho.userid,
	    blogcontent.blogcontent

        FROM whomadewho INNER JOIN bloglisting ON whomadewho.blogid = bloglisting.blogid
	                    INNER JOIN blogcontent ON blogcontent.blogid = bloglisting.blogid
		WHERE whomadewho.userid = ?");
    $stmt->bind_param("s", $loggedInUser->user_id);
    $stmt->execute();
    $stmt->bind_result($blogid, $title, $datecreated, $deleteflag, $active, $userid, $blogcontent);
    while ($stmt->fetch()){
        $row[] = array('blogid'       => $blogid,
            'title'        => $title,
            'datecreated'  => $datecreated,
            'deleteflag'   => $deleteflag,
            'active'       => $active,
            'userid'       => $userid,
            'blogcontent'  => $blogcontent
        );
    }
    $stmt->close();
    return ($row);
}

function fetchThisBlog($blogid) {
    global $loggedInUser, $mysqli,$db_table_prefix;
    $stmt = $mysqli->prepare("SELECT
		bloglisting.blogid,
		bloglisting.title,
	    bloglisting.datecreated,
	    bloglisting.deleteflag,
	    bloglisting.active,
	    whomadewho.userid,
	    blogcontent.blogcontent,
	    UserDetails.UserName,
	    UserDetails.FirstName,
	    UserDetails.LastName,
	    UserDetails.Email

        FROM whomadewho INNER JOIN bloglisting ON whomadewho.blogid = bloglisting.blogid
	 INNER JOIN UserDetails ON whomadewho.userid = UserDetails.UserID
	 INNER JOIN blogcontent ON blogcontent.blogid = bloglisting.blogid
		WHERE bloglisting.blogid = ?");
    $stmt->bind_param("s", $blogid);
    $stmt->execute();
    $stmt->bind_result($blogid, $title, $datecreated, $deleteflag, $active, $userid, $blogcontent, $username, $firstname, $lastname, $email);
    while ($stmt->fetch()){
        $row = array('blogid'       => $blogid,
            'title'        => $title,
            'datecreated'  => $datecreated,
            'deleteflag'   => $deleteflag,
            'active'       => $active,
            'userid'       => $userid,
            'blogcontent'  => $blogcontent,
            'username' => $username,
            'firstname' => $firstname,
            'lastname' => $lastname,
            'email'  => $email
        );
    }
    $stmt->close();
    return ($row);
}

function publishStatus($status,$blogid){
    global $loggedInUser, $mysqli,$db_table_prefix;
    if($status == 'publish'){
        $flag = 1;
    }else{
        $flag = 0;
    }
    $stmt = $mysqli->prepare("UPDATE `bloglisting` SET `active`=? WHERE `blogid` = ?");
    $stmt->bind_param("is",$flag,$blogid);
    $result = $stmt->execute();
    $stmt->close();
    return $result;
}
function updateThisBlog($blogid,$title,$blog,$publishStatus){
    global $loggedInUser, $mysqli,$db_table_prefix;
    if($publishStatus=='publish'){
        $flag = 1;
    }else if($publishStatus=='unpublish'){
        $flag = 0;
    }
    $stmt = $mysqli->prepare("UPDATE `bloglisting` SET `title` = ?, `active` = ? WHERE `blogid` = ? LIMIT 1");
    $stmt->bind_param("sis",$title,$flag,$blogid);
    $result = $stmt->execute();
    $stmt->close();

    $stmt = $mysqli->prepare("UPDATE `blogcontent` SET `blogcontent`= ? WHERE `blogid`=?");
    $stmt->bind_param("ss",$blog,$blogid);
    $result = $stmt->execute();
    $stmt->close();
    return $result;

}

function fetchUserDetails($email) {
    global $mysqli,$db_table_prefix;
    $stmt = $mysqli->prepare("SELECT
		UserID,
		FirstName,
		LastName,
		Email,
		Password,
		MemberSince,
		Active,
        role,
        request
		FROM ".$db_table_prefix."UserDetails
		WHERE
		Email = ?
		LIMIT 1");
    $stmt->bind_param("s", $email);

    $stmt->execute();
    $stmt->bind_result($UserID,$FirstName, $LastName, $Email, $Password, $MemberSince, $Active, $role, $request);
    while ($stmt->fetch()){
        $row = array('UserID' => $UserID,

            'FirstName' => $FirstName,
            'LastName' => $LastName,
            'Email' => $Email,
            'Password' => $Password,
            'MemberSince' => $MemberSince,
            'Active' => $Active,
            'role'=> $role,
            'request'=>$request);
    }
    $stmt->close();
    return ($row);
}

function getRoleDetails($role){
    global $mysqli;
    $stmt = $mysqli -> prepare("SELECT rolename FROM userroles WHERE role = ?");
    $stmt -> bind_param("i",$role);
    $stmt -> execute();
    $stmt -> bind_result($rolename);
    while($stmt -> fetch()){
        $rolename = $rolename;
    }
    $stmt -> close();
    return($rolename);
}

function fetchThisProduct($watch_id)

{
    global $mysqli;
    $stmt = $mysqli->prepare(
        "
    SELECT
    watch_id,
    name,
    type,
    brand,
    description,
    price,
    quantity,
    availability,
    gender,
    image

    FROM product
    WHERE
    watch_id=?"
    );
    $stmt->bind_param("s", $watch_id);
    $stmt->execute();
    $stmt->bind_result($watch_id, $name, $type, $brand, $description, $price, $quantity, $availability, $gender, $image);
    $stmt->execute();
    while ($stmt->fetch()) {
        $row[] = array(
            'watch_id'                      => $watch_id,
            'name'                  => $name,
            'type'               => $type,
            'brand'                => $brand,
            'description'                    => $description,
            'price'                     => $price,
            'quantity'             => $quantity,
            'availability'                   => $availability,
            'gender'             => $gender,
            'image'                  => $image


        );
    }
    $stmt->close();
    return ($row);
}

function fetchAllUsers() {

    global $mysqli,$db_table_prefix;
    $stmt = $mysqli->prepare("SELECT
		UserID,
		FirstName,
		LastName,
		Email,
		MemberSince,
		Active,
		role,
		request
		FROM ".$db_table_prefix."UserDetails
		");

    $stmt->execute();
    $stmt->bind_result($UserID, $FirstName, $LastName, $Email, $MemberSince, $Active, $role, $request);
    while ($stmt->fetch()){
        $row[] = array('UserID' => $UserID,

            'FirstName' => $FirstName,
            'LastName' => $LastName,
            'Email' => $Email,
            'MemberSince' => $MemberSince,
            'Active' => $Active,
            'role' => $role,
            'request' => $request);
    }
    $stmt->close();
    return ($row);
}



function updateThisRecord($name, $type, $brand, $description, $price, $quantity, $availability, $gender,$image, $watch_id)
{

    global $mysqli, $db_table_prefix;
    $stmt = $mysqli->prepare(
        "UPDATE " . $db_table_prefix . "product
		SET 
	    name = ?,
		type = ?,
		brand = ?,
		description = ?,
		price = ?,
		quantity = ?,
		availability = ?,
		gender = ?,
		image = ?
		WHERE
		watch_id = ?
	"
    );
    $stmt->bind_param("ssssssssss", $name, $type, $brand, $description, $price, $quantity, $availability, $gender,$image,$watch_id);
    $result = $stmt->execute();
    $stmt->close();

    return $result;
}

function deleteuser($UserID){
    global $mysqli;
    $stmt = $mysqli->prepare("DELETE FROM userdetails WHERE UserID= ? ");
    $stmt->bind_param('s',$UserID);
    $result = $stmt->execute();
    $stmt->close();
    return "<br>Delete record</br>";
}



?>