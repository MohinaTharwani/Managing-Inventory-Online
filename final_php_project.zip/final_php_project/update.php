<?php

require_once("config.php");
session_start();
$thiswatchid = $_GET['watch_id'];
echo $thiswatchid;

$foundUser = fetchThisProduct($thiswatchid);
echo "<pre>";
echo "</pre>";
?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
    <title>

    </title>
    <!-- Style -- Can also be included as a file usually style.css -->
    <style type="text/css">
        table.table-style-three {
            font-family: verdana, arial, sans-serif;
            font-size: 11px;
            color: #333333;
            border-width: 1px;
            border-color: #3A3A3A;
            border-collapse: collapse;
        }
        table.table-style-three th {
            border-width: 1px;
            padding: 8px;
            border-style: solid;
            border-color: #FFA6A6;
            background-color: #D56A6A;
            color: #ffffff;
        }
        table.table-style-three a {
            color: #ffffff;
            text-decoration: none;
        }

        table.table-style-three tr:hover td {
            cursor: pointer;
        }
        table.table-style-three tr:nth-child(even) td{
            background-color: #F7CFCF;
        }
        table.table-style-three td {
            border-width: 1px;
            padding: 8px;
            border-style: solid;
            border-color: #FFA6A6;
            background-color: #ffffff;
        }
    </style>

</head>
<body>

<form name="getUserDetails" method="post" action="processupdateproduct.php">
    <table class="table-style-three">
        <?php foreach ($foundUser as $userdetails) { ?>
            <tr><td>Name :</td>      <td><input type="text" name="name" value="<?php print $userdetails['name']; ?>"></td></tr>
            <tr><td>Type :</td>       <td><input type="radio" name="type"value="<?php print $userdetails['type']; ?>">Casual wear<br>
                    <input type="radio" name="type"value="<?php print $userdetails['type']; ?>">Smart Watch<br>
                    <input type="radio" name="type"value="<?php print $userdetails['type']; ?>">Sports Watch


                </td></tr>
            <tr><td>Brand :</td>  <td><input type="radio" name="brand" value="<?php print $userdetails['brand']; ?>">Rolex<br>
                    <input type="radio" name="brand" value="<?php print $userdetails['brand']; ?>">Fossil<br>
                    <input type="radio" name="brand" value="<?php print $userdetails['brand']; ?>">Invicta<br>
                    <input type="radio" name="brand" value="<?php print $userdetails['brand']; ?>">Guess
                </td>
                </tr>
            <tr><td>Description :</td>          <td><input type="text" name="description" cols='300' rows='10' value="<?php print $userdetails['description']; ?>"></td></tr>
            <tr><td>Price :</td>           <td><input type="number" name="price" value="<?php print $userdetails['price']; ?>"></td></tr>
            <tr><td>Quantity :</td>            <td><input type="number" name="quantity" value="<?php print $userdetails['quantity']; ?>"></td></tr>
            <tr><td>Availability :</td>          <td>  <input type="radio" name="availability" value="<?php print $userdetails['availability']; ?>">InStcok<br>
                <input type="radio" name="availability" value="<?php print $userdetails['availability']; ?>">Out oF Stock
                </td></tr>

            <tr><td>Gender :</td>            <td><input type="radio" name="gender" value="<?php print $userdetails['gender']; ?>">Male<br>
                    <input type="radio" name="gender" value="<?php print $userdetails['gender']; ?>">Female
                </td></tr>
            <tr><td>Image :</td>     <tr><td><iframe name="imageUpFrame" src="uploadForm.php" frameborder="0" scrolling="no"></iframe>
                </td><td> <?php print $userdetails['image'];?></td></tr>


            <tr><td>WatchID : </td>      <td><input type="text" name="useriddisabled" value="<?php print $userdetails['watch_id'];?>" disabled></td></tr>
            <input type="hidden" name="watch_id" value="<?php print $userdetails['watch_id'];?>" >
        <?php } ?>
    </table>

    <input type="submit" name="submit" value="Update Product">

</form>


</body>
</html>