<form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="fileToUpload" id="imageUploadID" accept="image/*">
    <input type="submit" value="Upload Image" name="submit">
</form>