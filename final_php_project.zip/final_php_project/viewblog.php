<?php


require_once("config.php");
require_once("header.php");

$thisblogid = $_GET['blogid'];
$thisblog = fetchThisBlog($thisblogid);
print_r($_GET['role']);
if($_GET['role'] == 'superuser'){

    echo "
<body>
<div id='wrapper'>

<div id='content'>

<h2>Blogs, Blogs and More Blogs!!!</h2>

<div id='left-nav'>";
    include("left-nav.php");

    echo "
</div>
<div id='main'><form method='post' action='updateThisBlog.php?role=superuser'>";
    echo "<br><br><br>";
    echo "<input type='hidden' name='blogid' value=$thisblogid>";
    echo "<h1 style='color: red;'>"; print $thisblog['title']; echo "</h1>";
    echo "<br><br><br><br>";
    echo "<h3 style='color:blue;'>"; print $thisblog['blogcontent']; echo "</h3>";
    if($thisblog['active']==1){
        echo "<label>Published<input type='radio' name='publishStatus' value='publish' checked='checked'></label> ";
        echo "<label>Unpublish<input type='radio' name='publishStatus' value='unpublish'></label></br>";
    }else{
        echo "<label>Publish<input type='radio' name='publishStatus' value='publish'></label> ";
        echo "<label>Unpublished<input type='radio' name='publishStatus' value='unpublish' checked='checked'></label></br>";
    }
    echo "<button type='submit'>Update</button>";
    echo "</form>";


}else if($_GET['role'] == 'generalUser'){
    echo "
<body>
<div id='wrapper'>

<div id='content'>

<h2>Blogs, Blogs and More Blogs!!!</h2>

<div id='left-nav'>";
    include("left-nav.php");

    echo "
</div>
<div id='main'>";
    echo "<br><br><br>";

    echo "<h1 style='color: red;'>"; print $thisblog['title']; echo "</h1>";
    echo "<br><br><br><br>";
    echo "<h3 style='color:blue;'>"; print $thisblog['blogcontent']; echo "</h3>";
}


