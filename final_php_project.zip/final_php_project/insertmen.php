<html>
<head>
    <title>
        Insert product
    </title>
    <!-- Style -- Can also be included as a file usually style.css -->
    <style type="text/css">
        table.table-style-three {
            font-family: verdana, arial, sans-serif;
            font-size: 11px;
            color: #333333;
            border-width: 1px;
            border-color: #3A3A3A;
            border-collapse: collapse;
        }
        table.table-style-three th {
            border-width: 1px;
            padding: 8px;
            border-style: solid;
            border-color: #FFA6A6;
            background-color: #D56A6A;
            color: #ffffff;
        }
        table.table-style-three a {
            color: #ffffff;
            text-decoration: none;
        }

        table.table-style-three tr:hover td {
            cursor: pointer;
        }
        table.table-style-three tr:nth-child(even) td{
            background-color: #F7CFCF;
        }
        table.table-style-three td {
            border-width: 1px;
            padding: 8px;
            border-style: solid;
            border-color: #FFA6A6;
            background-color: #ffffff;
        }
    </style>

</head>
<body>

<?php
//require_once("config.php");

echo '<form name="createNewRecord" action="insertmen_dbinsert.php" method="post">
  <!-- Table goes in the document BODY -->
  <table class="table-style-three">
      <thead>
      <!-- Display CRUD options in TH format -->
      <tr>
        <th>Watch Name</th>
        <td><input type="text" name="name" value=""></td>
      </tr>

      <tr>
        <th>Watch Type</th><td> 
        <input type="radio" name="type" value="casual_wear">Casual wear<br>
 <input type="radio" name="type" value="smart_watch">Smart Watch<br>
 <input type="radio" name="type" value="sports_watch">Sports Watch<br>
      <tr><th>Gender</th>
      <td> <input type="radio" name="gender" value="male"> Male<br>
  <input type="radio" name="gender" value="female"> Female</td>
</tr>
      <tr>
        <th>Brand</th><td>
        <input type="radio" name="brand" value="Invicta">Invicta<br>
  <input type="radio" name="brand" value="Fossil">Fossil<br>
 <input type="radio" name="brand" value="Guess">Guess<br>
  <input type="radio" name="brand" value="Rolex">Rolex<br>
   
      </td></tr>

      <tr>
        <th>Description</th><td>
        <textarea name="description" cols="500" rows="10"></textarea></td>
      </tr>
      <tr>
      <th>Product Image</th>
      <td><iframe name="imageUpFrame" src="uploadForm.php" frameborder="0" scrolling="no"></iframe> </td>
</tr>

      <tr>
        <th>Price</th>
        <td><input type="number" name="price" value=""></td>
      </tr>

      <tr>
        <th>Quantity</th>
        <td><input type="number" name="quantity" value=""></td>
      </tr>
 <tr>
        <th>Availability</th><td>
         <input type="radio" name="availability" value="In Stock">In Stock<br>
  <input type="radio" name="availability" value="Out of Stock">Out of Stock<br>
  </td>
      </tr>
      <tr>
        <td><input type="submit" name="submit" value="create record"></td>
      </tr>
      </thead>
    </table>
  </form>
</body>
</html>';

?>






