<?php
/**
 * Created by PhpStorm.
 * User: Jeswani Tarun Haresh
 * Date: 12/20/2016
 * Time: 12:11 AM
 */

echo '<form action="upload.php" method="post" enctype="multipart/form-data">
         Select image to upload:
       <input type="file" name="fileToUpload" id="imageUploadID" accept="image/*">
       <input type="submit" value="Upload Image" name="submit">
     </form>';

?>