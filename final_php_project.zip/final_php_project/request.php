<?php
include 'config.php';

if($_GET){
    echo "<pre>",print_r($_GET);
    request($loggedInUser->user_id);
}

?>