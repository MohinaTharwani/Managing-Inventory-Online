<?php


session_start();

?>

<html>
<head>
    <title>Men | Watches</title>
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href="css/bootstrap.css" rel='stylesheet' type='text/css' />
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <!-- Custom Theme files -->
    <link href="css/style.css" rel='stylesheet' type='text/css' />
    <link href="css/component.css" rel='stylesheet' type='text/css' />
    <!-- Custom Theme files -->
    <!--webfont-->
    <link href='//fonts.googleapis.com/css?family=PT+Sans+Narrow:400,700' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Dorsa' rel='stylesheet' type='text/css'>
    <script type="text/javascript" src="js/jquery-1.11.1.min.js"></script>
    <!-- start menu -->
    <link href="css/megamenu.css" rel="stylesheet" type="text/css" media="all" />
    <script type="text/javascript" src="js/megamenu.js"></script>
    <script>$(document).ready(function(){$(".megamenu").megamenu();});</script>
    <script src="js/jquery.easydropdown.js"></script>
    <script src="js/simpleCart.min.js"> </script>
</head>
<body>
<div class="men_banner">
    <div class="container">
        <div class="header_top">
            <div class="header_top_left">
                <div class="box_11"><a href="checkout.html">
                        <h4><p>Cart: <span class="simpleCart_total"></span> (<span id="simpleCart_quantity" class="simpleCart_quantity"></span> items)</p><img src="images/bag.png" alt=""/><div class="clearfix"> </div></h4>
                    </a></div>
                <p class="empty"><a href="javascript:;" class="simpleCart_empty">Empty Cart</a></p>
                <div class="clearfix"> </div>
            </div>
            <div class="header_top_right">

                    <div class="clearfix"> </div>
                </ul>
                <!-- start search to implement further-->
                <div class="search-box">
                    <div id="sb-search" class="sb-search">
                        <form>
                            <input class="sb-search-input" placeholder="Enter your search term..." type="search" name="search" id="search">
                            <input class="sb-search-submit" type="submit" value="">
                            <span class="sb-icon-search"> </span>
                        </form>
                    </div>
                </div>
                <!----search-scripts---->
                <script src="js/classie1.js"></script>
                <script src="js/uisearch.js"></script>
                <script>
new UISearch( document.getElementById( 'sb-search' ) );
                </script>
                <!----//search-scripts---->
                <div class="clearfix"> </div>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="header_bottom">
            <div class="logo">
                <h1><a href="index.php"><span class="m_1">W</span>atches</a></h1>
            </div>
            <div class="menu">
                <ul class="megamenu skyblue">
                    <li class="active grid"><a class="color2" href="displaymen.php">Mens</a>
                        <div class="megapanel">
                            <div class="row">
                                <div class="col1">
                                    <div class="h_nav">
                                        <h4>Men</h4>
                                        <ul>
                                            <li><a href="casualmen.php">Casual Wear</a></li>
                                            <li><a href="smartmen.php">Smart Watch</a></li>
                                            <li><a href="sportsmen.php">Sports Watch</a></li>


                                        </ul>
                                    </div>
                                </div>

                                <div class="col2">
                                    <div class="h_nav">
                                        <h4>Trends</h4>
                                        <ul>
                                            <li class>
                                                <div class="p_left">
                                                    <img src="images/p1.jpg" class="img-responsive" alt=""/>
                                                </div>
                                                <div class="p_right">
                                                    <h4><a href="#">Denim shirt</a></h4>
                                                    <span class="item-cat"><small><a href="#">watches</a></small></span>
                                                    <span class="price">29.99 $</span>
                                                </div>
                                                <div class="clearfix"> </div>
                                            </li>
                                            <li>
                                                <div class="p_left">
                                                    <img src="images/p2.jpg" class="img-responsive" alt=""/>
                                                </div>
                                                <div class="p_right">
                                                    <h4><a href="#">Denim shirt</a></h4>
                                                    <span class="item-cat"><small><a href="#">watches</a></small></span>
                                                    <span class="price">29.99 $</span>
                                                </div>
                                                <div class="clearfix"> </div>
                                            </li>
                                            <li>
                                                <div class="p_left">
                                                    <img src="images/p3.jpg" class="img-responsive" alt=""/>
                                                </div>
                                                <div class="p_right">
                                                    <h4><a href="#">Denim shirt</a></h4>
                                                    <span class="item-cat"><small><a href="#">watches</a></small></span>
                                                    <span class="price">29.99 $</span>
                                                </div>
                                                <div class="clearfix"> </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li><a class="color4" href="displaywomen.php">womens</a>
                        <div class="megapanel">
                            <div class="row">
                                <div class="col1">
                                    <div class="h_nav">
                                        <h4>Women</h4>
                                        <ul>
                                            <li><a href="casualwomen.php">Casual Wear</a></li>
                                            <li><a href="smartwomen.php">Smart Watch</a></li>
                                            <li><a href="sportswomen.php">Sports Watch</a></li>

                                    </div>
                                </div>

                                <div class="col2">
                                    <div class="h_nav">
                                        <h4>Trends</h4>
                                        <ul>
                                            <li class>
                                                <div class="p_left">
                                                    <img src="images/p1.jpg" class="img-responsive" alt=""/>
                                                </div>
                                                <div class="p_right">
                                                    <h4><a href="#">Denim shirt</a></h4>
                                                    <span class="item-cat"><small><a href="#">watches</a></small></span>
                                                    <span class="price">29.99 $</span>
                                                </div>
                                                <div class="clearfix"> </div>
                                            </li>
                                            <li>
                                                <div class="p_left">
                                                    <img src="images/p2.jpg" class="img-responsive" alt=""/>
                                                </div>
                                                <div class="p_right">
                                                    <h4><a href="#">Denim shirt</a></h4>
                                                    <span class="item-cat"><small><a href="#">watches</a></small></span>
                                                    <span class="price">29.99 $</span>
                                                </div>
                                                <div class="clearfix"> </div>
                                            </li>
                                            <li>
                                                <div class="p_left">
                                                    <img src="images/p3.jpg" class="img-responsive" alt=""/>
                                                </div>
                                                <div class="p_right">
                                                    <h4><a href="#">Denim shirt</a></h4>
                                                    <span class="item-cat"><small><a href="#">watches</a></small></span>
                                                    <span class="price">29.99 $</span>
                                                </div>
                                                <div class="clearfix"> </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </li>
                    <li><a class="color4" href="#">Brands</a>
                        <div class="megapanel">
                            <div class="row">
                                <div class="col1">
                                    <div class="h_nav">
                                        <h4>BRANDS</h4>
                                        <ul>
                                            <li><a href="invicta.php">Invicta</a></li>
                                            <li><a href="fossil.php">Fossil</a></li>
                                            <li><a href="guess.php">Guess</a></li>
                                            <li><a href="rolex.php">Rolex</a></li>
                                            <li><a href="longines.php">Longines</a></li>
                                            <li><a href="moto.php">Motorola - SmartWatch</a></li>
                                            <li><a href="apple.php">Apple - SmartWatch</a></li>								</ul>
                                    </div>
                                </div>

                                <!--   <li class="active grid"><a class="color3" href="index.html">Sale</a></li>-->
                    <li><a class="color4" href="#">Accessories</a>
            </div>

            <div class="clearfix"> </div>
        </div>
    </div>
</div>
<div class="men">
        <div class="col-md-8 mens_right">

                            <div id="cbp-vm" class="cbp-vm-switcher cbp-vm-view-grid">

                <div class="clearfix"></div>
                                <ul><?php

require_once("config.php");

//Assigning $_POST values to individual variables for reuse.
$name = $_POST['name'];
$type = $_POST['type'];
$brand = $_POST['brand'];
$description = $_POST['description'];
//$image=$_POST['image'];
$price = $_POST['price'];
$quantity = $_POST['quantity'];
$availability = $_POST['availability'];
$gender = $_POST['gender'];
//getting image
// var_dump($_FILES)

$image = $_SESSION['image'];

$men=insertmen($name, $type, $brand, $description, $price, $quantity, $availability, $gender, $image);

unset($_SESSION['image']);
echo" <li class=\"last simpleCart_shelfItem\">
                            <div class=\"view view-first\">
                                <div class=\"inner_content clearfix\">
                                    <div class=\"product_image\">
                                        <div class=\"mask1\"><img src='images/".$image."' alt=\"image\" class=\"img-responsive zoom-img\"></div>
                                        <div class=\"mask\">
                                            <div class=\"info\">Quick View</div>
                                        </div>
                                        <div class=\"product_container\">
                                            <h4>$name</h4>
                                            <p>$brand</p>
                                            <p>$quantity</p>
                                            <p>$availability</p>
                                            <div class=\"price mount item_price\">$price</div>
                                            <a class=\"button item_add cbp-vm-icon cbp-vm-add\" href=\"#\">Add to cart</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </li>"



                                    ?>

</ul>
</div>
<script src="js/cbpViewModeSwitch.js" type="text/javascript"></script>
<script src="js/classie.js" type="text/javascript"></script>
</div>
</div>
</div>

</body>
</html>

<?php
//
//unset($_SESSION['image']);
//session_destroy();
//
//?>
<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!--
<!DOCTYPE HTML>
