<?php
/**
 * Created by PhpStorm.
 * User: Jeswani Tarun Haresh
 * Date: 10/24/2016
 * Time: 6:01 PM
 */


require_once("config.php");

$thiswatch_id = $_GET['watch_id'];
echo $thiswatch_id;

$foundwatch = deletewatch($thiswatch_id);
echo "<pre>";
print_r($foundwatch);
echo "</pre>";
?>

<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Transitional//EN' 'http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd'>
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8' />
    <title>
       Delete
    </title>
    <!-- Style -- Can also be included as a file usually style.css -->
    <style type="text/css">
        table.table-style-three {
            font-family: verdana, arial, sans-serif;
            font-size: 11px;
            color: #333333;
            border-width: 1px;
            border-color: #3A3A3A;
            border-collapse: collapse;
        }
        table.table-style-three th {
            border-width: 1px;
            padding: 8px;
            border-style: solid;
            border-color: #FFA6A6;
            background-color: #D56A6A;
            color: #ffffff;
        }
        table.table-style-three a {
            color: #ffffff;
            text-decoration: none;
        }

        table.table-style-three tr:hover td {
            cursor: pointer;
        }
        table.table-style-three tr:nth-child(even) td{
            background-color: #F7CFCF;
        }
        table.table-style-three td {
            border-width: 1px;
            padding: 8px;
            border-style: solid;
            border-color: #FFA6A6;
            background-color: #ffffff;
        }
    </style>

</head>
<body>

<form name="" method="post" action="processdeletewatch.php">
    <table class="table-style-three">
        <?php foreach ($foundwatch as $watchdetails) { ?>
            <tr><td>Name :</td>      <td><input type="text" name="name" value="<?php print $watchdetails['name']; ?>"></td></tr>
            <tr><td>Type :</td>       <td><input type="text" name="type" value="<?php print $watchdetails['type']; ?>"></td></tr>
            <tr><td>Brand :</td>  <td><input type="text" name="brand" value="<?php print $watchdetails['brand']; ?>"></td></tr>
            <tr><td>Description :</td>          <td><input type="text" name="description" value="<?php print $watchdetails['description']; ?>"></td></tr>
            <tr><td>Image :</td>           <td><input type="text" name="image" value="<?php print $watchdetails['image']; ?>"></td></tr>
            <tr><td>Price:</td>            <td><input type="text" name="Price" value="<?php print $watchdetails['price']; ?>"></td></tr>
            <tr><td>Quantity : </td>      <td><input type="text" name="quantity" value="<?php print $watchdetails['quantity'];?>"></td></tr>
            <tr><td>Availability : </td>      <td><input type="text" name="availability" value="<?php print $watchdetails['availability'];?>"></td></tr>
            <tr><td>Gender : </td>      <td><input type="text" name="gender" value="<?php print $watchdetails['gender'];?>"></td></tr>
            <input type="hidden" name="watch_id" value="<?php print $watchdetails['watch_id'];?>" >
        <?php } ?>
    </table>

    <input type="submit" name="submit" value="Delete Record">

</form>


</body>
</html>