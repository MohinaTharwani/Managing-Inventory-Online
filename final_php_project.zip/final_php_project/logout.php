<?php
/**
 * Created by PhpStorm.
 * User: Jeswani Tarun Haresh
 * Date: 12/20/2016
 * Time: 9:07 PM
 */
session_start();
if(!Empty($_SESSION)){
    unset($_SESSION["ThisUser"]);
    session_destroy();
    echo "Logged ou now!!";

    header("Location: index.php");

}

else{
    echo "Alreday logged out!";

    header("Location: index.php");
}